#include <ros/ros.h>
#include <geometry_msgs/PoseStamped.h>
#include <mavros_msgs/State.h>
#include <mavros_msgs/SetMode.h>
#include <vector>

// 记录当前状态
mavros_msgs::State current_state;
void state_cb(const mavros_msgs::State::ConstPtr& msg){
    current_state = *msg;
}

int main(int argc, char **argv) {
    ros::init(argc, argv, "takeoff_node");
    ros::NodeHandle nh;

    // 订阅和发布话题，注意 XTDrone 中 iris 0 的命名空间是 iris_0
    ros::Subscriber state_sub = nh.subscribe<mavros_msgs::State>("iris_0/mavros/state", 10, state_cb);
    ros::Publisher local_pos_pub = nh.advertise<geometry_msgs::PoseStamped>("iris_0/mavros/setpoint_position/local", 10);
    
    // 【已修复】去掉了多余的 "nh." 笔误
    ros::ServiceClient set_mode_client = nh.serviceClient<mavros_msgs::SetMode>("iris_0/mavros/set_mode");

    ros::Rate rate(20.0);

    // 等待飞控连接
    while(ros::ok() && !current_state.connected){
        ros::spinOnce();
        rate.sleep();
    }

    // 定义航点队列 (x, y, z)
    std::vector<geometry_msgs::PoseStamped> waypoints;
    std::vector<std::vector<double>> points = {
        {0, 0, 3}, {5, 0, 3}, {5, 5, 3}, {0, 5, 3}, {0, 0, 3}
    };

    // 将简化的坐标转化为 ROS 消息格式
    for(auto p : points) {
        geometry_msgs::PoseStamped target;
        target.pose.position.x = p[0];
        target.pose.position.y = p[1];
        target.pose.position.z = p[2];
        waypoints.push_back(target);
    }

    // 在切换到 OFFBOARD 模式前，必须先发送足够多的目标点作为心跳
    for(int i = 100; ros::ok() && i > 0; --i){
        local_pos_pub.publish(waypoints[0]);
        ros::spinOnce();
        rate.sleep();
    }

    // 【已优化】使用 size_t 匹配 vector 的 size() 类型，防止编译警告
    size_t current_wp_idx = 0; 
    ROS_INFO("Ready! Please switch to OFFBOARD mode and ARM using keyboard.");

    while(ros::ok()){
        // 持续发布当前航点
        local_pos_pub.publish(waypoints[current_wp_idx]);

        // 当键盘控制脚本切换到 OFFBOARD 模式后，开始执行航点逻辑
        if(current_state.mode == "OFFBOARD") {
            static int arrival_counter = 0;
            arrival_counter++;
            
            // 每个点给大约 7.5 秒的飞行时间 (150 个循环 / 20Hz = 7.5 秒)
            if(arrival_counter > 150) { 
                if(current_wp_idx < waypoints.size() - 1) {
                    current_wp_idx++;
                    arrival_counter = 0;
                    ROS_INFO("Moving to next waypoint: %lu", current_wp_idx);
                } else if (current_wp_idx == waypoints.size() - 1) {
                    // 飞完所有航点，请求切换到自动降落模式
                    mavros_msgs::SetMode land_set_mode;
                    land_set_mode.request.custom_mode = "AUTO.LAND";
                    if(set_mode_client.call(land_set_mode) && land_set_mode.response.mode_sent){
                        ROS_INFO("Mission completed. Landing...");
                        break; // 退出循环，结束节点
                    }
                }
            }
        }

        ros::spinOnce();
        rate.sleep();
    }

    return 0;
}
